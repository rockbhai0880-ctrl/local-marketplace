// ==================== CHECK AUTH STATUS ====================
(function checkAuth() {
  // If on login or register page, check if already logged in
  if (window.location.pathname.includes('index.html') || window.location.pathname.includes('register.html')) {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      window.location.href = 'dashboard.html';
    }
  } else {
    // If on any other page, check if logged in
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
      window.location.href = 'index.html';
    }
  }
})();

// ==================== INITIALIZE USERS STORAGE ====================
if (!localStorage.getItem('users')) {
  localStorage.setItem('users', JSON.stringify([]));
}

// ==================== LOGIN FORM HANDLER ====================
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    
    // Get users from storage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Find user
    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
      // Store current user (excluding password for safety)
      const userToStore = {
        id: user.id,
        fullname: user.fullname,
        username: user.username,
        email: user.email,
        phone: user.phone
      };
      
      localStorage.setItem('currentUser', JSON.stringify(userToStore));
      
      // Show success message
      alert('Login successful!');
      window.location.href = 'dashboard.html';
    } else {
      alert('Invalid username or password');
    }
  });
}

// ==================== REGISTER FORM HANDLER ====================
const registerForm = document.getElementById('registerForm');
if (registerForm) {
  registerForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form values
    const fullname = document.getElementById('fullname').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const username = document.getElementById('regUsername').value.trim();
    const password = document.getElementById('regPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Validation
    if (!fullname || !email || !phone || !username || !password) {
      alert('All fields are required');
      return;
    }
    
    if (password !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    
    if (password.length < 6) {
      alert('Password must be at least 6 characters');
      return;
    }
    
    // Get existing users
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Check if username already exists
    if (users.some(u => u.username === username)) {
      alert('Username already taken');
      return;
    }
    
    // Check if email already exists
    if (users.some(u => u.email === email)) {
      alert('Email already registered');
      return;
    }
    
    // Create new user
    const newUser = {
      id: Date.now().toString(),
      fullname,
      email,
      phone,
      username,
      password,
      joined: new Date().toISOString()
    };
    
    // Save to storage
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    // Auto login
    const userToStore = {
      id: newUser.id,
      fullname: newUser.fullname,
      username: newUser.username,
      email: newUser.email,
      phone: newUser.phone
    };
    
    localStorage.setItem('currentUser', JSON.stringify(userToStore));
    
    alert('Registration successful!');
    window.location.href = 'dashboard.html';
  });
}