// ==================== GLOBAL VARIABLES ====================
let currentUser = null;
let products = [];
let comments = [];

// ==================== INITIALIZE STORAGE ====================
if (!localStorage.getItem('products')) {
    // Sample products with images (using placeholders)
    const sampleProducts = [
        {
            id: '1',
            userId: 'sample1',
            sellerName: 'John Doe',
            sellerPhone: '+1234567890',
            title: 'iPhone 12 - 128GB',
            price: '299',
            condition: 'Like New',
            category: 'Electronics',
            description: 'iPhone 12 in perfect condition. Battery health 95%. Comes with original charger and box. No scratches or damages.',
            location: 'New York, NY',
            image: 'https://images.unsplash.com/photo-1605540436563-5bca919ae766?w=400',
            date: new Date().toISOString()
        },
        {
            id: '2',
            userId: 'sample2',
            sellerName: 'Jane Smith',
            sellerPhone: '+1234567891',
            title: 'Wooden Dining Table',
            price: '150',
            condition: 'Good',
            category: 'Furniture',
            description: 'Solid wood dining table, seats 6 people. Minor scratches on surface but very sturdy. Free local pickup.',
            location: 'Brooklyn, NY',
            image: 'https://images.unsplash.com/photo-1577140917170-285929fb55b7?w=400',
            date: new Date().toISOString()
        },
        {
            id: '3',
            userId: 'sample1',
            sellerName: 'John Doe',
            sellerPhone: '+1234567890',
            title: 'Nike Air Max',
            price: '89',
            condition: 'Good',
            category: 'Clothing',
            description: 'Nike Air Max sneakers, size 10. Worn only a few times, still in great condition.',
            location: 'New York, NY',
            image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400',
            date: new Date().toISOString()
        }
    ];
    localStorage.setItem('products', JSON.stringify(sampleProducts));
}

if (!localStorage.getItem('comments')) {
    localStorage.setItem('comments', JSON.stringify([]));
}

// Initialize user avatars storage
if (!localStorage.getItem('userAvatars')) {
    localStorage.setItem('userAvatars', JSON.stringify({}));
}

// ==================== LOAD CURRENT USER ====================
function loadCurrentUser() {
    const userData = localStorage.getItem('currentUser');
    if (userData) {
        currentUser = JSON.parse(userData);
    }
    return currentUser;
}

// ==================== DISPLAY USER PROFILE WITH EDITABLE FIELDS ====================
function displayUserProfile() {
    const profileHeader = document.getElementById('profileHeader');
    if (!profileHeader || !currentUser) return;
    
    // Get user avatar if exists
    const avatars = JSON.parse(localStorage.getItem('userAvatars')) || {};
    const userAvatar = avatars[currentUser.id] || null;
    
    let avatarHtml = '';
    if (userAvatar) {
        avatarHtml = `<img src="${userAvatar}" alt="${currentUser.fullname}">`;
    } else {
        // Get initials for placeholder
        const initials = currentUser.fullname.split(' ').map(n => n[0]).join('').toUpperCase();
        avatarHtml = `<div class="avatar-placeholder">${initials}</div>`;
    }
    
    profileHeader.innerHTML = `
        <div class="profile-avatar-section">
            <div class="profile-avatar">
                ${avatarHtml}
                <button class="change-avatar-btn" onclick="document.getElementById('avatarUpload').click()">
                    <i class="fas fa-camera"></i>
                </button>
            </div>
            <div class="avatar-name">
                <h2>${currentUser.fullname}</h2>
                <p><i class="fas fa-user"></i> @${currentUser.username}</p>
            </div>
        </div>
        
        <div class="profile-info-edit">
            <!-- Full Name (Editable) -->
            <div class="info-row" id="nameRow">
                <i class="fas fa-user"></i>
                <div class="info-content">
                    <label>Full Name</label>
                    <span id="displayName">${currentUser.fullname}</span>
                    <input type="text" id="editName" value="${currentUser.fullname}" style="display: none;">
                </div>
                <button class="edit-info-btn" onclick="toggleEdit('name')" id="editNameBtn">
                    <i class="fas fa-pen"></i>
                </button>
                <button class="save-info-btn" onclick="saveEdit('name')" id="saveNameBtn" style="display: none;">
                    <i class="fas fa-check"></i> Save
                </button>
            </div>
            
            <!-- Email (Editable) -->
            <div class="info-row" id="emailRow">
                <i class="fas fa-envelope"></i>
                <div class="info-content">
                    <label>Email Address</label>
                    <span id="displayEmail">${currentUser.email}</span>
                    <input type="email" id="editEmail" value="${currentUser.email}" style="display: none;">
                </div>
                <button class="edit-info-btn" onclick="toggleEdit('email')" id="editEmailBtn">
                    <i class="fas fa-pen"></i>
                </button>
                <button class="save-info-btn" onclick="saveEdit('email')" id="saveEmailBtn" style="display: none;">
                    <i class="fas fa-check"></i> Save
                </button>
            </div>
            
            <!-- Phone (Editable) -->
            <div class="info-row" id="phoneRow">
                <i class="fas fa-phone"></i>
                <div class="info-content">
                    <label>Phone Number</label>
                    <span id="displayPhone">${currentUser.phone}</span>
                    <input type="tel" id="editPhone" value="${currentUser.phone}" style="display: none;">
                </div>
                <button class="edit-info-btn" onclick="toggleEdit('phone')" id="editPhoneBtn">
                    <i class="fas fa-pen"></i>
                </button>
                <button class="save-info-btn" onclick="saveEdit('phone')" id="savePhoneBtn" style="display: none;">
                    <i class="fas fa-check"></i> Save
                </button>
            </div>
            
            <!-- Username (Editable) -->
            <div class="info-row" id="usernameRow">
                <i class="fas fa-user-circle"></i>
                <div class="info-content">
                    <label>Username</label>
                    <span id="displayUsername">${currentUser.username}</span>
                    <input type="text" id="editUsername" value="${currentUser.username}" style="display: none;">
                </div>
                <button class="edit-info-btn" onclick="toggleEdit('username')" id="editUsernameBtn">
                    <i class="fas fa-pen"></i>
                </button>
                <button class="save-info-btn" onclick="saveEdit('username')" id="saveUsernameBtn" style="display: none;">
                    <i class="fas fa-check"></i> Save
                </button>
            </div>
        </div>
    `;
}

// ==================== TOGGLE EDIT MODE ====================
function toggleEdit(field) {
    // Hide display span, show input
    document.getElementById(`display${field.charAt(0).toUpperCase() + field.slice(1)}`).style.display = 'none';
    document.getElementById(`edit${field.charAt(0).toUpperCase() + field.slice(1)}`).style.display = 'block';
    
    // Hide edit button, show save button
    document.getElementById(`edit${field.charAt(0).toUpperCase() + field.slice(1)}Btn`).style.display = 'none';
    document.getElementById(`save${field.charAt(0).toUpperCase() + field.slice(1)}Btn`).style.display = 'inline-block';
}

// ==================== SAVE EDITED FIELD ====================
function saveEdit(field) {
    // Get new value
    const newValue = document.getElementById(`edit${field.charAt(0).toUpperCase() + field.slice(1)}`).value.trim();
    
    if (!newValue) {
        alert(`${field} cannot be empty`);
        return;
    }
    
    // Update currentUser
    if (field === 'name') {
        currentUser.fullname = newValue;
    } else if (field === 'email') {
        // Validate email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(newValue)) {
            alert('Please enter a valid email address');
            return;
        }
        currentUser.email = newValue;
    } else if (field === 'phone') {
        currentUser.phone = newValue;
    } else if (field === 'username') {
        // Check if username already exists (excluding current user)
        const users = JSON.parse(localStorage.getItem('users')) || [];
        if (users.some(u => u.username === newValue && u.id !== currentUser.id)) {
            alert('Username already taken');
            return;
        }
        currentUser.username = newValue;
    }
    
    // Update in users array
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    if (userIndex !== -1) {
        // Update password to keep it (since we don't store password in currentUser)
        users[userIndex] = {
            ...users[userIndex],
            fullname: currentUser.fullname,
            email: currentUser.email,
            phone: currentUser.phone,
            username: currentUser.username
        };
        localStorage.setItem('users', JSON.stringify(users));
    }
    
    // Update currentUser in storage
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    // Update display
    document.getElementById(`display${field.charAt(0).toUpperCase() + field.slice(1)}`).textContent = newValue;
    
    // Toggle back
    document.getElementById(`display${field.charAt(0).toUpperCase() + field.slice(1)}`).style.display = 'inline';
    document.getElementById(`edit${field.charAt(0).toUpperCase() + field.slice(1)}`).style.display = 'none';
    document.getElementById(`edit${field.charAt(0).toUpperCase() + field.slice(1)}Btn`).style.display = 'inline-block';
    document.getElementById(`save${field.charAt(0).toUpperCase() + field.slice(1)}Btn`).style.display = 'none';
    
    // Show success message
    showNotification('Information updated successfully!', 'success');
}

// ==================== HANDLE AVATAR UPLOAD ====================
const avatarUpload = document.getElementById('avatarUpload');
if (avatarUpload) {
    avatarUpload.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        // Check file size (max 2MB)
        if (file.size > 2 * 1024 * 1024) {
            alert('Image size should be less than 2MB');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(event) {
            const imageData = event.target.result;
            
            // Save to localStorage
            const avatars = JSON.parse(localStorage.getItem('userAvatars')) || {};
            avatars[currentUser.id] = imageData;
            localStorage.setItem('userAvatars', JSON.stringify(avatars));
            
            // Refresh profile display
            displayUserProfile();
            
            showNotification('Profile picture updated!', 'success');
        };
        reader.readAsDataURL(file);
    });
}

// ==================== SHOW NOTIFICATION ====================
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Style the notification
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '1rem 1.5rem';
    notification.style.background = type === 'success' ? 'var(--success)' : 'var(--primary)';
    notification.style.color = 'white';
    notification.style.borderRadius = '10px';
    notification.style.boxShadow = 'var(--shadow-lg)';
    notification.style.zIndex = '3000';
    notification.style.display = 'flex';
    notification.style.alignItems = 'center';
    notification.style.gap = '0.5rem';
    notification.style.animation = 'slideInRight 0.3s ease';
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// ==================== LOAD PRODUCTS ====================
function loadProducts(searchTerm = '', sortBy = 'newest') {
    const productsGrid = document.getElementById('productsGrid');
    if (!productsGrid) return;
    
    let allProducts = JSON.parse(localStorage.getItem('products')) || [];
    
    // Filter by search term
    if (searchTerm) {
        const term = searchTerm.toLowerCase();
        allProducts = allProducts.filter(p => 
            p.title.toLowerCase().includes(term) ||
            p.description.toLowerCase().includes(term) ||
            p.category.toLowerCase().includes(term)
        );
    }
    
    // Sort products
    allProducts.sort((a, b) => {
        if (sortBy === 'newest') {
            return new Date(b.date) - new Date(a.date);
        } else if (sortBy === 'priceLow') {
            return parseFloat(a.price) - parseFloat(b.price);
        } else if (sortBy === 'priceHigh') {
            return parseFloat(b.price) - parseFloat(a.price);
        }
    });
    
    if (allProducts.length === 0) {
        productsGrid.innerHTML = '<div class="loading"><i class="fas fa-box-open"></i> No products found</div>';
        return;
    }
    
    productsGrid.innerHTML = '';
    
    allProducts.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

// ==================== CREATE PRODUCT CARD (WITH IMAGE) ====================
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => showProductDetail(product);
    
    const date = new Date(product.date).toLocaleDateString();
    
    // Image HTML
    let imageHtml = '';
    if (product.image) {
        imageHtml = `<img src="${product.image}" alt="${product.title}">`;
    } else {
        imageHtml = `
            <div class="no-image">
                <i class="fas fa-image"></i>
                <span>No Image</span>
            </div>
        `;
    }
    
    card.innerHTML = `
        <div class="product-image">
            ${imageHtml}
        </div>
        <div class="product-info">
            <h3 class="product-title">${product.title}</h3>
            <div class="product-price">$${product.price}</div>
            <div class="product-badges">
                <span class="product-condition">${product.condition}</span>
                <span class="product-category">${product.category}</span>
            </div>
            <div class="product-seller">
                <i class="fas fa-user"></i> ${product.sellerName}
            </div>
            <div class="product-phone">
                <i class="fab fa-whatsapp"></i> ${product.sellerPhone}
            </div>
            <div style="font-size:0.85rem; color:var(--gray); margin-top:0.5rem;">
                <i class="fas fa-map-marker-alt"></i> ${product.location} • ${date}
            </div>
        </div>
    `;
    
    return card;
}

// ==================== SHOW PRODUCT DETAIL (WITH IMAGE) ====================
function showProductDetail(product) {
    const modal = document.getElementById('productModal');
    const detailDiv = document.getElementById('productDetail');
    
    if (!modal || !detailDiv) return;
    
    const date = new Date(product.date).toLocaleDateString();
    
    // Image HTML
    let imageHtml = '';
    if (product.image) {
        imageHtml = `<img src="${product.image}" alt="${product.title}">`;
    } else {
        imageHtml = `<i class="fas fa-image"></i>`;
    }
    
    detailDiv.innerHTML = `
        <div class="detail-image">
            ${imageHtml}
        </div>
        <h2 class="detail-title">${product.title}</h2>
        <div class="detail-price">$${product.price}</div>
        
        <div class="detail-badges">
            <span class="detail-condition">${product.condition}</span>
            <span class="detail-category">${product.category}</span>
        </div>
        
        <div class="detail-description">
            <p>${product.description}</p>
        </div>
        
        <div class="detail-seller">
            <h4><i class="fas fa-user"></i> Seller Information</h4>
            <p><i class="fas fa-user"></i> Name: ${product.sellerName}</p>
            <p><i class="fas fa-map-marker-alt"></i> Location: ${product.location}</p>
            <p><i class="fas fa-calendar"></i> Posted: ${date}</p>
        </div>
        
        <a href="https://wa.me/${product.sellerPhone.replace(/\+/g, '')}?text=Hi, I'm interested in your ad: ${product.title} ($${product.price})" 
           target="_blank" class="detail-phone">
            <i class="fab fa-whatsapp"></i> Contact via WhatsApp
        </a>
    `;
    
    modal.classList.add('show');
}

// ==================== LOAD MY ADS ====================
function loadMyAds() {
    const myAdsGrid = document.getElementById('myAdsGrid');
    if (!myAdsGrid || !currentUser) return;
    
    const allProducts = JSON.parse(localStorage.getItem('products')) || [];
    const myProducts = allProducts.filter(p => p.userId === currentUser.id);
    
    if (myProducts.length === 0) {
        myAdsGrid.innerHTML = '<div class="loading"><i class="fas fa-box-open"></i> You haven\'t posted any ads yet</div>';
        return;
    }
    
    myAdsGrid.innerHTML = '';
    
    myProducts.forEach(product => {
        const adCard = document.createElement('div');
        adCard.className = 'my-ad-card';
        
        adCard.innerHTML = `
            <h3>${product.title}</h3>
            <div class="price">$${product.price}</div>
            <span class="condition">${product.condition}</span>
            <span class="category">${product.category}</span>
            <div style="margin-top:0.5rem; color:var(--gray);">
                <i class="fas fa-map-marker-alt"></i> ${product.location}
            </div>
            <button class="delete-ad" onclick="deleteAd('${product.id}')">
                <i class="fas fa-trash"></i>
            </button>
        `;
        
        myAdsGrid.appendChild(adCard);
    });
}

// ==================== DELETE AD ====================
function deleteAd(productId) {
    if (!confirm('Are you sure you want to delete this ad? It cannot be undone.')) {
        return;
    }
    
    const allProducts = JSON.parse(localStorage.getItem('products')) || [];
    const updatedProducts = allProducts.filter(p => p.id !== productId);
    
    localStorage.setItem('products', JSON.stringify(updatedProducts));
    
    showNotification('Ad deleted successfully', 'success');
    loadMyAds(); // Reload the ads
}

// ==================== POST AD FORM HANDLER (WITH IMAGE) ====================
const postAdForm = document.getElementById('postAdForm');
if (postAdForm) {
    postAdForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!currentUser) {
            alert('You must be logged in to post an ad');
            return;
        }
        
        const title = document.getElementById('adTitle').value.trim();
        const price = document.getElementById('adPrice').value;
        const category = document.getElementById('adCategory').value;
        const condition = document.getElementById('adCondition').value;
        const location = document.getElementById('adLocation').value.trim();
        const description = document.getElementById('adDescription').value.trim();
        const imageFile = document.getElementById('adImage').files[0];
        
        if (!title || !price || !category || !condition || !location || !description) {
            alert('All fields are required');
            return;
        }
        
        // Handle image upload
        if (imageFile) {
            // Check file size (max 2MB)
            if (imageFile.size > 2 * 1024 * 1024) {
                alert('Image size should be less than 2MB');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(event) {
                saveProductWithImage(event.target.result);
            };
            reader.readAsDataURL(imageFile);
        } else {
            saveProductWithImage(null);
        }
    });
}

function saveProductWithImage(imageData) {
    const title = document.getElementById('adTitle').value.trim();
    const price = document.getElementById('adPrice').value;
    const category = document.getElementById('adCategory').value;
    const condition = document.getElementById('adCondition').value;
    const location = document.getElementById('adLocation').value.trim();
    const description = document.getElementById('adDescription').value.trim();
    
    const newProduct = {
        id: Date.now().toString(),
        userId: currentUser.id,
        sellerName: currentUser.fullname,
        sellerPhone: currentUser.phone,
        title,
        price,
        condition,
        category,
        description,
        location,
        image: imageData, // Will be null if no image
        date: new Date().toISOString()
    };
    
    const allProducts = JSON.parse(localStorage.getItem('products')) || [];
    allProducts.unshift(newProduct);
    localStorage.setItem('products', JSON.stringify(allProducts));
    
    // Reset form
    document.getElementById('postAdForm').reset();
    
    showNotification('Ad posted successfully!', 'success');
    
    // Reload my ads if on profile page
    if (window.location.pathname.includes('profile.html')) {
        loadMyAds();
    }
}

// ==================== LOAD COMMENTS ====================
function loadComments() {
    const commentsList = document.getElementById('commentsList');
    if (!commentsList) return;
    
    const allComments = JSON.parse(localStorage.getItem('comments')) || [];
    
    if (allComments.length === 0) {
        commentsList.innerHTML = '<h3>Recent Comments</h3><div class="loading"><i class="fas fa-comment-dots"></i> No comments yet</div>';
        return;
    }
    
    let commentsHtml = '<h3>Recent Comments</h3>';
    
    allComments.reverse().forEach(comment => {
        const date = new Date(comment.date).toLocaleDateString();
        commentsHtml += `
            <div class="comment">
                <div class="comment-header">
                    <span>${comment.name}</span>
                    <span class="comment-date">${date}</span>
                </div>
                <div class="comment-text">${comment.message}</div>
            </div>
        `;
    });
    
    commentsList.innerHTML = commentsHtml;
}

// ==================== COMMENT FORM HANDLER ====================
const commentForm = document.getElementById('commentForm');
if (commentForm) {
    commentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('commentName').value.trim();
        const email = document.getElementById('commentEmail').value.trim();
        const message = document.getElementById('commentMessage').value.trim();
        
        if (!name || !email || !message) {
            alert('All fields are required');
            return;
        }
        
        const newComment = {
            id: Date.now().toString(),
            name,
            email,
            message,
            date: new Date().toISOString()
        };
        
        const allComments = JSON.parse(localStorage.getItem('comments')) || [];
        allComments.push(newComment);
        localStorage.setItem('comments', JSON.stringify(allComments));
        
        // Reset form
        commentForm.reset();
        
        showNotification('Comment posted successfully!', 'success');
        loadComments();
    });
}

// ==================== LOGOUT FUNCTION ====================
function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'index.html';
}

// ==================== SEARCH HANDLER ====================
const searchInput = document.getElementById('searchProducts');
const searchBtn = document.getElementById('searchBtn');

if (searchBtn && searchInput) {
    searchBtn.addEventListener('click', function() {
        loadProducts(searchInput.value);
    });
    
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            loadProducts(searchInput.value);
        }
    });
}

// ==================== SORT HANDLER ====================
const sortSelect = document.getElementById('sortProducts');
if (sortSelect) {
    sortSelect.addEventListener('change', function() {
        loadProducts(searchInput?.value || '', this.value);
    });
}

// ==================== CATEGORY CLICK HANDLER ====================
document.querySelectorAll('.category-card').forEach(card => {
    card.addEventListener('click', function() {
        const category = this.dataset.category;
        if (searchInput) {
            searchInput.value = category;
            loadProducts(category);
            
            // Scroll to products
            document.querySelector('.products-section').scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// ==================== MODAL HANDLERS ====================
const closeProductModal = document.getElementById('closeProductModal');
if (closeProductModal) {
    closeProductModal.addEventListener('click', function() {
        document.getElementById('productModal').classList.remove('show');
    });
}

// Close modal when clicking outside
window.addEventListener('click', function(e) {
    const modal = document.getElementById('productModal');
    if (e.target === modal) {
        modal.classList.remove('show');
    }
});

// ==================== MOBILE MENU TOGGLE ====================
const mobileToggle = document.getElementById('mobileToggle');
const mobileMenu = document.getElementById('mobileMenu');

if (mobileToggle && mobileMenu) {
    mobileToggle.addEventListener('click', function() {
        mobileMenu.classList.toggle('show');
    });
}

// ==================== LOGOUT BUTTONS ====================
document.querySelectorAll('#logoutBtn, #mobileLogout').forEach(btn => {
    if (btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    }
});

// ==================== ADD ANIMATION STYLES ====================
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ==================== PAGE LOAD INIT ====================
document.addEventListener('DOMContentLoaded', function() {
    // Load current user
    loadCurrentUser();
    
    // Check which page we're on and load appropriate content
    const path = window.location.pathname;
    
    if (path.includes('dashboard.html')) {
        displayUserName();
        loadProducts();
        
        // Set up search and sort
        if (searchInput) searchInput.value = '';
        if (sortSelect) sortSelect.value = 'newest';
        
    } else if (path.includes('profile.html')) {
        displayUserProfile();
        loadMyAds();
        
    } else if (path.includes('about.html')) {
        loadComments();
    }
});

// Helper function to display username in dashboard
function displayUserName() {
    const userNameSpan = document.getElementById('userNameDisplay');
    if (userNameSpan && currentUser) {
        userNameSpan.textContent = currentUser.fullname.split(' ')[0];
    }
}